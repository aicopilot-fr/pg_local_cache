# pg_local_cache SQL-only benchmark

Generated: `2026-08-03T10:02:14.201335+00:00`

SQL-only `local_cache.mget(regclass, anyarray)` compared with a stock PostgreSQL primary-key batch lookup designed to return the same ordered row JSON. The first, middle, and last rows are compared byte-for-byte. Both use the same LOGIN NOSUPERUSER, key stream, rows, and wire protocol. The mapped server has `pg_local_cache.port=0`; no RESP listener, client, or token is used.

## Throughput and end-to-end latency

| Protocol | Mode | Throughput profile | Median throughput | Latency profile | Mean | p50 | p95 | p99 | Samples |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| prepared | Stock PostgreSQL (no extension) | c16/k32 | 6 306 ops/s | c16/k1 | 0.762 ms | 0.583 ms | 1.969 ms | 3.338 ms | 23 925 |
| prepared | Mapped table, cache off | c16/k32 | 6 280 ops/s | c16/k1 | 0.764 ms | 0.591 ms | 1.973 ms | 3.299 ms | 23 955 |
| prepared | pg_local_cache, cache on | c16/k32 | 64 954 ops/s | c16/k1 | 0.955 ms | 0.815 ms | 1.940 ms | 3.505 ms | 21 619 |
| extended | Stock PostgreSQL (no extension) | c16/k32 | 6 365 ops/s | c16/k1 | 1.176 ms | 1.032 ms | 2.506 ms | 4.093 ms | 19 042 |
| extended | Mapped table, cache off | c16/k32 | 6 257 ops/s | c16/k1 | 1.168 ms | 1.043 ms | 2.411 ms | 3.620 ms | 19 390 |
| extended | pg_local_cache, cache on | c16/k32 | 66 156 ops/s | c16/k1 | 1.229 ms | 1.110 ms | 2.452 ms | 3.847 ms | 18 602 |

Latency is measured in separate, rotated repetitions with one scalar key read per transaction. This is a closed-loop saturation measurement, not an equal offered-rate test. Aggregate percentiles are recomputed from the retained raw samples. Throughput is batch TPS multiplied by the configured keys per MGET.

## c4/k8 and c16/k32 scaling snapshot

| Protocol | Mode | Throughput profile | Median throughput | Latency profile | Mean | p50 | p95 | p99 | Samples |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| prepared | Stock PostgreSQL (no extension) | c4/k8 | 36 241 ops/s | c4/k1 | 0.233 ms | 0.214 ms | 0.402 ms | 0.501 ms | 4 537 |
| prepared | Stock PostgreSQL (no extension) | c16/k32 | 6 306 ops/s | c16/k1 | 0.762 ms | 0.583 ms | 1.969 ms | 3.338 ms | 23 925 |
| prepared | Mapped table, cache off | c4/k8 | 35 318 ops/s | c4/k1 | 0.236 ms | 0.217 ms | 0.403 ms | 0.536 ms | 4 435 |
| prepared | Mapped table, cache off | c16/k32 | 6 280 ops/s | c16/k1 | 0.764 ms | 0.591 ms | 1.973 ms | 3.299 ms | 23 955 |
| prepared | pg_local_cache, cache on | c4/k8 | 42 777 ops/s | c4/k1 | 0.278 ms | 0.253 ms | 0.469 ms | 0.612 ms | 3 975 |
| prepared | pg_local_cache, cache on | c16/k32 | 64 954 ops/s | c16/k1 | 0.955 ms | 0.815 ms | 1.940 ms | 3.505 ms | 21 619 |
| extended | Stock PostgreSQL (no extension) | c4/k8 | 28 784 ops/s | c4/k1 | 0.316 ms | 0.289 ms | 0.524 ms | 0.673 ms | 3 633 |
| extended | Stock PostgreSQL (no extension) | c16/k32 | 6 365 ops/s | c16/k1 | 1.176 ms | 1.032 ms | 2.506 ms | 4.093 ms | 19 042 |
| extended | Mapped table, cache off | c4/k8 | 28 364 ops/s | c4/k1 | 0.314 ms | 0.287 ms | 0.528 ms | 0.681 ms | 3 611 |
| extended | Mapped table, cache off | c16/k32 | 6 257 ops/s | c16/k1 | 1.168 ms | 1.043 ms | 2.411 ms | 3.620 ms | 19 390 |
| extended | pg_local_cache, cache on | c4/k8 | 41 589 ops/s | c4/k1 | 0.328 ms | 0.299 ms | 0.553 ms | 0.723 ms | 3 519 |
| extended | pg_local_cache, cache on | c16/k32 | 66 156 ops/s | c16/k1 | 1.229 ms | 1.110 ms | 2.452 ms | 3.847 ms | 18 602 |

The MGET key width applies to throughput only. Latency uses one scalar key read per transaction: c4/k1 and c16/k1. The c4/k8 snapshot uses 1 repetition; its performance values are non-gating. c16/k32 references the 3-repetition strict profile above without copying its raw latency samples.

## Relative throughput and gates

| Protocol | Cache/stock | Cache/mapped-off | Throughput gate | Relative gate | Latency gate |
|---|---:|---:|---:|---:|---:|
| prepared | 10.30x | 10.34x | **PASS** (>= 10 000 ops/s) | **PASS** | **MEASURED** (no p99 limit configured) |
| extended | 10.39x | 10.57x | **PASS** (>= 10 000 ops/s) | **PASS** | **MEASURED** (no p99 limit configured) |

## Correctness evidence

| Proof | Hits | Misses | Fills | Bypasses |
|---|---:|---:|---:|---:|
| cold read -> fill -> warm read | 1 | 1 | 1 | 0 |
| complete 4096-key warm pass | 0 | 4096 | 4096 | 0 |
| 3-row stock/mapped/cache check | 3 | 0 | 0 | 0 |

Every cached timed run requires `hits == successful key reads` and zero misses, fills, or bypasses. Every direct run requires all four SQL-cache counter deltas to be zero.

## Workload

| Parameter | Value |
|---|---:|
| Requested/effective duration per measured run | 5.0 / 5 s |
| Requested/effective warmup per mode | 2.0 / 2 s |
| Requested/effective latency duration per mode | 5.0 / 5 s |
| Latency sampling rate | 0.1 |
| Minimum latency samples per run/mode | 2000 |
| Repetitions per mode/protocol | 3 |
| Concurrent connections | 16 |
| pgbench jobs | 4 |
| Keys per SQL MGET | 32 |
| Distinct KV rows | 4096 |
| Text payload bytes | 3000 |

Overall gate: **PASS** — both SQL-only protocol gates and all exact accounting checks passed

Prepared and unnamed-extended results have independent >=10k gates and are never pooled. Cache/direct and cache/stock ratio gates are reported separately. A rotating three-mode order reduces run-order bias. All modes use identical schema, data, returned bytes, role, key stream, connections, jobs, duration, and protocol settings; SQL differs only because stock PostgreSQL has no `mget`.

# pg_local_cache whole-row benchmark

Generated: `2026-08-03T09:58:01.402426+00:00`

Every RESP target receives the same key stream and byte-identical per-key row JSON values.

## Full-row RESP GET

| Target | Median ops/s | Min-max ops/s | p99 | Errors |
|---|---:|---:|---:|---:|
| pg_local_cache | 150 569 | 150 569-150 569 | 0.394 ms | 0 |
| valkey | 201 248 | 201 248-201 248 | 0.281 ms | 0 |
| redis | 205 430 | 205 430-205 430 | 0.271 ms | 0 |

## Ordinary SQL whole-row/projection lanes

| Lane | Mapped PostgreSQL median ops/s | Stock PostgreSQL median ops/s |
|---|---:|---:|
| select_star | 126 710 | 65 257 |
| reordered_projection | 123 051 | 65 236 |
| composite_predicate_reordered | 131 017 | 71 398 |

## pg_local_cache full-row response-width sweep

| Text payload bytes | JSON response bytes | Median ops/s | p99 |
|---:|---:|---:|---:|
| 64 | 181-192 | 152 988 | 0.340 ms |
| 512 | 629-640 | 148 142 | 0.358 ms |
| 2048 | 2165-2176 | 131 402 | 0.458 ms |

Overall gate: **PASS** — all independent whole-row gates and integrity checks passed

RESP values are PostgreSQL `row_to_json` bytes. Valkey and Redis store exactly those bytes; pg_local_cache derives them from the authoritative table and maintains transactional invalidation.
SQL values are validated before timing. Prepared/pipelined pgbench uses identical SELECT text against mapped and stock PostgreSQL.

# pg_local_cache whole-row benchmark

Generated: `2026-08-03T08:10:18.863944+00:00`

Every RESP target receives the same key stream and byte-identical per-key row JSON values.

## Full-row RESP GET

| Target | Median ops/s | Min-max ops/s | p99 | Errors |
|---|---:|---:|---:|---:|
| pg_local_cache | 149 703 | 149 703-149 703 | 0.374 ms | 0 |
| valkey | 199 345 | 199 345-199 345 | 0.265 ms | 0 |
| redis | 200 137 | 200 137-200 137 | 0.269 ms | 0 |

## Ordinary SQL whole-row/projection lanes

| Lane | Mapped PostgreSQL median ops/s | Stock PostgreSQL median ops/s |
|---|---:|---:|
| select_star | 126 169 | 67 017 |
| reordered_projection | 120 354 | 62 733 |
| composite_predicate_reordered | 130 133 | 71 284 |

## pg_local_cache full-row response-width sweep

| Text payload bytes | JSON response bytes | Median ops/s | p99 |
|---:|---:|---:|---:|
| 64 | 181-192 | 156 117 | 0.356 ms |
| 512 | 629-640 | 142 275 | 0.384 ms |
| 2048 | 2165-2176 | 128 488 | 0.429 ms |

Overall gate: **PASS** — all independent whole-row gates and integrity checks passed

RESP values are PostgreSQL `row_to_json` bytes. Valkey and Redis store exactly those bytes; pg_local_cache derives them from the authoritative table and maintains transactional invalidation.
SQL values are validated before timing. Prepared/pipelined pgbench uses identical SELECT text against mapped and stock PostgreSQL.

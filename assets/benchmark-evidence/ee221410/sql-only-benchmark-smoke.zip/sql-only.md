# pg_local_cache SQL-only benchmark

Generated: `2026-08-03T08:14:45.391053+00:00`

SQL-only `local_cache.mget(regclass, anyarray)` compared with a byte-identical stock PostgreSQL primary-key batch lookup. Both use the same LOGIN NOSUPERUSER, key stream, rows, and wire protocol. The mapped server has `pg_local_cache.port=0`; no RESP listener, client, or token is used.

## Throughput and end-to-end latency

| Protocol | Mode | Throughput profile | Median throughput | Latency profile | Mean | p50 | p95 | p99 | Samples |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| prepared | Stock PostgreSQL (no extension) | c16/k32 | 7 992 ops/s | c16/k1 | 0.409 ms | 0.323 ms | 0.991 ms | 2.019 ms | 48 091 |
| prepared | Mapped table, cache off | c16/k32 | 8 049 ops/s | c16/k1 | 0.402 ms | 0.328 ms | 0.919 ms | 1.857 ms | 48 495 |
| prepared | pg_local_cache, cache on | c16/k32 | 111 103 ops/s | c16/k1 | 0.778 ms | 0.516 ms | 1.196 ms | 3.150 ms | 30 091 |
| extended | Stock PostgreSQL (no extension) | c16/k32 | 7 992 ops/s | c16/k1 | 0.601 ms | 0.568 ms | 1.150 ms | 1.649 ms | 38 201 |
| extended | Mapped table, cache off | c16/k32 | 7 976 ops/s | c16/k1 | 0.599 ms | 0.561 ms | 1.132 ms | 1.717 ms | 38 274 |
| extended | pg_local_cache, cache on | c16/k32 | 104 956 ops/s | c16/k1 | 0.846 ms | 0.601 ms | 1.356 ms | 2.787 ms | 28 689 |

Latency is measured in separate, rotated repetitions with one scalar key read per transaction. This is a closed-loop saturation measurement, not an equal offered-rate test. Aggregate percentiles are recomputed from the retained raw samples. Throughput is batch TPS multiplied by the configured keys per MGET.

## c4/k8 and c16/k32 scaling snapshot

| Protocol | Mode | Throughput profile | Median throughput | Latency profile | Mean | p50 | p95 | p99 | Samples |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| prepared | Stock PostgreSQL (no extension) | c4/k8 | 63 568 ops/s | c4/k1 | 0.112 ms | 0.104 ms | 0.190 ms | 0.247 ms | 9 780 |
| prepared | Stock PostgreSQL (no extension) | c16/k32 | 7 992 ops/s | c16/k1 | 0.409 ms | 0.323 ms | 0.991 ms | 2.019 ms | 48 091 |
| prepared | Mapped table, cache off | c4/k8 | 62 000 ops/s | c4/k1 | 0.113 ms | 0.105 ms | 0.194 ms | 0.254 ms | 9 611 |
| prepared | Mapped table, cache off | c16/k32 | 8 049 ops/s | c16/k1 | 0.402 ms | 0.328 ms | 0.919 ms | 1.857 ms | 48 495 |
| prepared | pg_local_cache, cache on | c4/k8 | 73 302 ops/s | c4/k1 | 0.149 ms | 0.134 ms | 0.260 ms | 0.344 ms | 7 528 |
| prepared | pg_local_cache, cache on | c16/k32 | 111 103 ops/s | c16/k1 | 0.778 ms | 0.516 ms | 1.196 ms | 3.150 ms | 30 091 |
| extended | Stock PostgreSQL (no extension) | c4/k8 | 42 491 ops/s | c4/k1 | 0.156 ms | 0.143 ms | 0.256 ms | 0.334 ms | 7 379 |
| extended | Stock PostgreSQL (no extension) | c16/k32 | 7 992 ops/s | c16/k1 | 0.601 ms | 0.568 ms | 1.150 ms | 1.649 ms | 38 201 |
| extended | Mapped table, cache off | c4/k8 | 42 590 ops/s | c4/k1 | 0.152 ms | 0.139 ms | 0.245 ms | 0.317 ms | 7 644 |
| extended | Mapped table, cache off | c16/k32 | 7 976 ops/s | c16/k1 | 0.599 ms | 0.561 ms | 1.132 ms | 1.717 ms | 38 274 |
| extended | pg_local_cache, cache on | c4/k8 | 68 439 ops/s | c4/k1 | 0.167 ms | 0.150 ms | 0.280 ms | 0.377 ms | 6 935 |
| extended | pg_local_cache, cache on | c16/k32 | 104 956 ops/s | c16/k1 | 0.846 ms | 0.601 ms | 1.356 ms | 2.787 ms | 28 689 |

The MGET key width applies to throughput only. Latency uses one scalar key read per transaction: c4/k1 and c16/k1. The c4/k8 snapshot uses 1 repetition; its performance values are non-gating. c16/k32 references the 3-repetition strict profile above without copying its raw latency samples.

## Relative throughput and gates

| Protocol | Cache/stock | Cache/mapped-off | Throughput gate | Relative gate | Latency gate |
|---|---:|---:|---:|---:|---:|
| prepared | 13.90x | 13.80x | **PASS** (>= 10 000 ops/s) | **PASS** | **MEASURED** (no p99 limit configured) |
| extended | 13.13x | 13.16x | **PASS** (>= 10 000 ops/s) | **PASS** | **MEASURED** (no p99 limit configured) |

## Correctness evidence

| Proof | Hits | Misses | Fills | Bypasses |
|---|---:|---:|---:|---:|
| cold read -> fill -> warm read | 1 | 1 | 1 | 0 |
| complete 4096-key warm pass | 0 | 4096 | 4096 | 0 |
| 3-row stock/mapped/cache check | 3 | 0 | 0 | 0 |

Every cached timed run requires `hits == successful key reads` and zero misses, fills, or bypasses. Every direct run requires all four SQL-cache counter deltas to be zero.

## Workload

| Parameter | Value |
|---|---:|
| Requested/effective duration per measured run | 5.0 / 5 s |
| Requested/effective warmup per mode | 2.0 / 2 s |
| Requested/effective latency duration per mode | 5.0 / 5 s |
| Latency sampling rate | 0.1 |
| Minimum latency samples per run/mode | 2000 |
| Repetitions per mode/protocol | 3 |
| Concurrent connections | 16 |
| pgbench jobs | 4 |
| Keys per SQL MGET | 32 |
| Distinct KV rows | 4096 |
| Text payload bytes | 3000 |

Overall gate: **PASS** — both SQL-only protocol gates and all exact accounting checks passed

Prepared and unnamed-extended results have independent >=10k gates and are never pooled. Cache/direct and cache/stock ratio gates are reported separately. A rotating three-mode order reduces run-order bias. All modes use identical schema, data, returned bytes, role, key stream, connections, jobs, duration, and protocol settings; SQL differs only because stock PostgreSQL has no `mget`.
